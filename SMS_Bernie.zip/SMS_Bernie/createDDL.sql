CREATE TABLE student (student_email VARCHAR(50) NOT NULL, student_name VARCHAR(50), student_password VARCHAR(50), PRIMARY KEY (student_email))
