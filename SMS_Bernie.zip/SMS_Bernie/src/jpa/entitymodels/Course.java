/**
 * 
 */
package jpa.entitymodels;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Bernard J. Girardot
 *
 */

/* Course.Java
 * 
 * Written by Bernard J. Girardot
 * 		   in Java 8
 *        for Per Scholas Java Full Stack developer class 118
 *        
 */

@Entity
@Table(name="course")
public class Course {
	
	@Id
	@Column(name="course_identifier")
	int courseId;
	
	@Column(name="course_name", length=50)
	String courseName;
	
	@Column(name="course_instructor_name", length=50)
	String courseInstructorName;
	
	public Course() {	
	}

	/**
	 * @param courseId
	 * @param courseName
	 * @param courseInstructorName
	 */
	public Course(int courseId, String courseName, String courseInstructorName) {
		super();
		this.courseId = courseId;
		this.courseName = courseName;
		this.courseInstructorName = courseInstructorName;
	}

	/**
	 * @return the courseId
	 */
	public int getCourseId() {
		return courseId;
	}

	/**
	 * @param courseId the courseId to set
	 */
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	/**
	 * @return the courseName
	 */
	public String getCourseName() {
		return courseName;
	}

	/**
	 * @param courseName the courseName to set
	 */
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	/**
	 * @return the courseInstructorName
	 */
	public String getCourseInstructorName() {
		return courseInstructorName;
	}

	/**
	 * @param courseInstructorName the courseInstructorName to set
	 */
	public void setCourseInstructorName(String courseInstructorName) {
		this.courseInstructorName = courseInstructorName;
	}

	@Override
	public String toString() {
		return "Course [courseId=" + courseId + ", courseName=" + courseName + ", courseInstructorName="
				+ courseInstructorName + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + courseId;
		result = prime * result + ((courseInstructorName == null) ? 0 : courseInstructorName.hashCode());
		result = prime * result + ((courseName == null) ? 0 : courseName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (courseId != other.courseId)
			return false;
		if (courseInstructorName == null) {
			if (other.courseInstructorName != null)
				return false;
		} else if (!courseInstructorName.equals(other.courseInstructorName))
			return false;
		if (courseName == null) {
			if (other.courseName != null)
				return false;
		} else if (!courseName.equals(other.courseName))
			return false;
		return true;
	}
	
}
