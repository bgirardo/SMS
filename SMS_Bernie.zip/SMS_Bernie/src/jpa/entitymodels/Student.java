/**
 * 
 */
package jpa.entitymodels;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author Bernard J. Girardot
 * 
 *
 */

/* This is the Student Class as defined by the requirements of the JPA SBA for
 * Java Full Stack Development class (Per Scholas, Java 118, Nov 2019 - Mar 2020.
 * 
 * Written on Feb 25, 2020 
 *         in Java 8
 *        for Per Scholas
 *         by Bernard J. Girardot
 *         
 * This entity will represent the student.
 */
@Entity
@Table(name="student")
public class Student {
	
	@Id
	@Column(name="student_email", length=50)
	String studenteMail;
	
	@Column(name="student_name", length=50)
	String studentName;
	
	@Column(name="student_password", length=50)
	String studentPassword;
	
	public Student() {
	}

	/**
	 * @param studenteMail
	 * @param studentName
	 * @param studentPassword
	 */
	public Student(String studenteMail, String studentName, String studentPassword) {
		super();
		this.studenteMail = studenteMail;
		this.studentName = studentName;
		this.studentPassword = studentPassword;
	}

	/**
	 * @return the studenteMail
	 */
	public String getStudenteMail() {
		return studenteMail;
	}

	/**
	 * @param studenteMail the studenteMail to set
	 */
	public void setStudenteMail(String studenteMail) {
		this.studenteMail = studenteMail;
	}

	/**
	 * @return the studentName
	 */
	public String getStudentName() {
		return studentName;
	}

	/**
	 * @param studentName the studentName to set
	 */
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	/**
	 * @return the studentPassword
	 */
	public String getStudentPassword() {
		return studentPassword;
	}

	/**
	 * @param studentPassword the studentPassword to set
	 */
	public void setStudentPassword(String studentPassword) {
		this.studentPassword = studentPassword;
	}

	@Override
	public String toString() {
		return "Student [studenteMail=" + studenteMail + ", studentName=" + studentName + ", studentPassword="
				+ studentPassword + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((studentName == null) ? 0 : studentName.hashCode());
		result = prime * result + ((studentPassword == null) ? 0 : studentPassword.hashCode());
		result = prime * result + ((studenteMail == null) ? 0 : studenteMail.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (studentName == null) {
			if (other.studentName != null)
				return false;
		} else if (!studentName.equals(other.studentName))
			return false;
		if (studentPassword == null) {
			if (other.studentPassword != null)
				return false;
		} else if (!studentPassword.equals(other.studentPassword))
			return false;
		if (studenteMail == null) {
			if (other.studenteMail != null)
				return false;
		} else if (!studenteMail.equals(other.studenteMail))
			return false;
		return true;
	}

}
