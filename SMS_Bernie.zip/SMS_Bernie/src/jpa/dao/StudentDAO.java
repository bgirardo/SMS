/**
 * 
 */
package jpa.dao;

/**
 * @author CTStudent
 *
 */
public interface StudentDAO {
	getAllStudents();
	getStudentByEmail();
	validateStudent();
	registerStudentToCourse();
	getStudentCourses();
}
