package jpa.dao;

public interface CourseDAO {
	getAllCourses();
}
