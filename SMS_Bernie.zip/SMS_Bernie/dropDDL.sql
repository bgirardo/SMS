DROP TABLE student
